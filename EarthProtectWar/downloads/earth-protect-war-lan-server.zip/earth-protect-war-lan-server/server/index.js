import { randomInt, randomUUID } from 'node:crypto';
import { createServer } from 'node:http';
import { WebSocket, WebSocketServer } from 'ws';
const DEFAULT_HOST = '0.0.0.0';
const DEFAULT_PORT = 8787;
const MAX_FACTION_PLAYERS = 8;
const MAX_MESSAGE_BYTES = 64 * 1024;
const HEARTBEAT_INTERVAL_MS = 15_000;
const CLIENT_TIMEOUT_MS = 45_000;
const ROOM_CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const ROOM_CODE_LENGTH = 6;
const clients = new Map();
const rooms = new Map();
const config = parseConfig(process.argv.slice(2), process.env);
const httpServer = createServer((request, response) => {
    handleHttpRequest(request, response);
});
const wsServer = new WebSocketServer({ noServer: true });
httpServer.on('upgrade', (request, socket, head) => {
    const requestUrl = new URL(request.url ?? '/', `http://${request.headers.host ?? 'localhost'}`);
    if (requestUrl.pathname !== '/ws') {
        rejectUpgrade(socket, 404, 'WebSocket endpoint is /ws');
        return;
    }
    wsServer.handleUpgrade(request, socket, head, (webSocket) => {
        wsServer.emit('connection', webSocket, request);
    });
});
wsServer.on('connection', (socket, request) => {
    const context = {
        id: randomUUID(),
        socket,
        remoteAddress: request.socket.remoteAddress ?? 'unknown',
        connectedAt: new Date().toISOString(),
        lastSeenAt: Date.now(),
        roomCode: null,
        playerId: null,
    };
    clients.set(context.id, context);
    sendToClient(context, {
        type: 'welcome',
        clientId: context.id,
        serverTime: Date.now(),
        limits: {
            maxFactionPlayers: MAX_FACTION_PLAYERS,
        },
    });
    socket.on('message', (rawData) => {
        context.lastSeenAt = Date.now();
        handleSocketMessage(context, rawData);
    });
    socket.on('pong', () => {
        context.lastSeenAt = Date.now();
    });
    socket.on('close', () => {
        leaveCurrentRoom(context, 'disconnect');
        clients.delete(context.id);
    });
    socket.on('error', () => {
        leaveCurrentRoom(context, 'socket_error');
        clients.delete(context.id);
    });
});
const heartbeatTimer = setInterval(() => {
    const now = Date.now();
    for (const context of clients.values()) {
        if (context.socket.readyState !== WebSocket.OPEN) {
            continue;
        }
        if (now - context.lastSeenAt > CLIENT_TIMEOUT_MS) {
            context.socket.close(1001, 'client timeout');
            continue;
        }
        context.socket.ping();
    }
}, HEARTBEAT_INTERVAL_MS);
heartbeatTimer.unref();
httpServer.listen(config.port, config.host, () => {
    console.log(`Earth Protect War LAN signaling server listening on ${config.host}:${config.port}`);
    console.log(`WebSocket endpoint: ws://${config.host}:${config.port}/ws`);
});
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
function handleHttpRequest(request, response) {
    const requestUrl = new URL(request.url ?? '/', `http://${request.headers.host ?? 'localhost'}`);
    setCorsHeaders(response);
    if (request.method === 'OPTIONS') {
        response.writeHead(204);
        response.end();
        return;
    }
    if (request.method === 'GET' && requestUrl.pathname === '/health') {
        sendJsonResponse(response, 200, {
            status: 'ok',
            serverTime: Date.now(),
            rooms: rooms.size,
            clients: clients.size,
            limits: {
                maxFactionPlayers: MAX_FACTION_PLAYERS,
            },
        });
        return;
    }
    if (request.method === 'GET' && requestUrl.pathname === '/rooms') {
        sendJsonResponse(response, 200, {
            serverTime: Date.now(),
            rooms: Array.from(rooms.values(), serializeRoom),
        });
        return;
    }
    if (request.method === 'GET' && requestUrl.pathname === '/ws') {
        sendJsonResponse(response, 426, {
            error: 'upgrade_required',
            message: 'Use WebSocket to connect to /ws.',
        });
        return;
    }
    sendJsonResponse(response, 404, {
        error: 'not_found',
        message: 'Available endpoints: GET /health, GET /rooms, WS /ws.',
    });
}
function handleSocketMessage(context, rawData) {
    const rawText = rawData.toString('utf8');
    if (rawText.length > MAX_MESSAGE_BYTES) {
        sendError(context, 'message_too_large', `Messages must be <= ${MAX_MESSAGE_BYTES} bytes.`);
        return;
    }
    let message;
    try {
        const parsed = JSON.parse(rawText);
        if (!isRecord(parsed)) {
            sendError(context, 'invalid_message', 'Message must be a JSON object.');
            return;
        }
        message = parsed;
    }
    catch {
        sendError(context, 'invalid_json', 'Message must be valid JSON.');
        return;
    }
    const requestId = getOptionalString(message.requestId);
    switch (message.type) {
        case 'create_room':
            handleCreateRoom(context, message, requestId);
            return;
        case 'join_room':
            handleJoinRoom(context, message, requestId);
            return;
        case 'leave_room':
            handleLeaveRoom(context, requestId);
            return;
        case 'set_faction':
            handleSetFaction(context, message, requestId);
            return;
        case 'set_ready':
            handleSetReady(context, message, requestId);
            return;
        case 'signal_to_host':
            handleSignalToHost(context, message, requestId);
            return;
        case 'signal_to_peer':
            handleSignalToPeer(context, message, requestId);
            return;
        case 'player_snapshot':
        case 'combat_event':
            sendError(context, 'game_relay_removed', 'Game traffic must use WebRTC DataChannel.', requestId);
            return;
        case 'ping':
            sendToClient(context, {
                type: 'pong',
                requestId,
                clientTime: message.clientTime ?? null,
                serverTime: Date.now(),
            });
            return;
        default:
            sendError(context, 'unknown_message_type', 'Unknown message type.', requestId);
    }
}
function handleCreateRoom(context, message, requestId) {
    const mode = normalizeRoomMode(message.mode);
    if (!mode) {
        sendError(context, 'invalid_mode', 'Room mode must be "coop" or "versus".', requestId);
        return;
    }
    const faction = normalizeFaction(message.faction ?? 'earth');
    if (!faction) {
        sendError(context, 'invalid_faction', 'Faction must be "earth" or "invader".', requestId);
        return;
    }
    if (!isFactionAllowedInMode(mode, faction)) {
        sendError(context, 'mode_faction_conflict', 'Coop rooms only allow the earth faction.', requestId);
        return;
    }
    leaveCurrentRoom(context, 'room_replaced');
    const requestedRoomCode = normalizeRoomCode(message.roomCode);
    const roomCode = requestedRoomCode ?? createUniqueRoomCode();
    const roomName = normalizeRoomName(message.roomName, roomCode);
    if (rooms.has(roomCode)) {
        sendError(context, 'room_exists', `Room ${roomCode} already exists.`, requestId);
        return;
    }
    const room = {
        code: roomCode,
        name: roomName,
        mode,
        hostPlayerId: context.id,
        combat: createDefaultRoomCombatState(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        players: new Map(),
    };
    addPlayerToRoom(context, room, {
        name: normalizePlayerName(message.playerName, context.id),
        faction,
    });
    rooms.set(room.code, room);
    context.roomCode = room.code;
    context.playerId = context.id;
    sendRoomJoined(context, room, requestId);
    broadcastRoomState(room);
}
function handleJoinRoom(context, message, requestId) {
    const roomCode = normalizeRoomCode(message.roomCode);
    if (!roomCode) {
        sendError(context, 'invalid_room_code', 'roomCode is required.', requestId);
        return;
    }
    const room = rooms.get(roomCode);
    if (!room) {
        sendError(context, 'room_not_found', `Room ${roomCode} was not found.`, requestId);
        return;
    }
    const faction = normalizeFaction(message.faction ?? 'earth');
    if (!faction) {
        sendError(context, 'invalid_faction', 'Faction must be "earth" or "invader".', requestId);
        return;
    }
    if (!canJoinFaction(room, faction)) {
        sendFactionJoinError(context, room, faction, requestId);
        return;
    }
    leaveCurrentRoom(context, 'room_replaced');
    addPlayerToRoom(context, room, {
        name: normalizePlayerName(message.playerName, context.id),
        faction,
    });
    context.roomCode = room.code;
    context.playerId = context.id;
    room.updatedAt = new Date().toISOString();
    sendRoomJoined(context, room, requestId);
    broadcastRoomState(room);
}
function handleLeaveRoom(context, requestId) {
    const roomCode = context.roomCode;
    leaveCurrentRoom(context, 'client_leave');
    sendToClient(context, {
        type: 'left_room',
        requestId,
        roomCode,
        serverTime: Date.now(),
    });
}
function handleSetFaction(context, message, requestId) {
    const room = getContextRoom(context);
    const player = getContextPlayer(context, room);
    if (!room || !player) {
        sendError(context, 'not_in_room', 'Join a room before changing faction.', requestId);
        return;
    }
    const faction = normalizeFaction(message.faction);
    if (!faction) {
        sendError(context, 'invalid_faction', 'Faction must be "earth" or "invader".', requestId);
        return;
    }
    if (player.faction === faction) {
        sendRoomJoined(context, room, requestId);
        return;
    }
    if (!canJoinFaction(room, faction)) {
        sendFactionJoinError(context, room, faction, requestId);
        return;
    }
    resetFinishedRoomCombat(room);
    player.faction = faction;
    player.ready = false;
    player.lastSeenAt = new Date().toISOString();
    room.updatedAt = new Date().toISOString();
    broadcastRoomState(room);
}
function handleSetReady(context, message, requestId) {
    const room = getContextRoom(context);
    const player = getContextPlayer(context, room);
    if (!room || !player) {
        sendError(context, 'not_in_room', 'Join a room before setting ready state.', requestId);
        return;
    }
    if (typeof message.ready !== 'boolean') {
        sendError(context, 'invalid_ready_state', 'ready must be true or false.', requestId);
        return;
    }
    resetFinishedRoomCombat(room);
    player.ready = message.ready;
    player.lastSeenAt = new Date().toISOString();
    room.updatedAt = new Date().toISOString();
    broadcastRoomState(room);
}
function handleSignalToHost(context, message, requestId) {
    const room = getContextRoom(context);
    const player = getContextPlayer(context, room);
    if (!room || !player) {
        sendError(context, 'not_in_room', 'Join a room before sending WebRTC signaling.', requestId);
        return;
    }
    if (player.id === room.hostPlayerId) {
        sendError(context, 'host_signal_target', 'The host cannot signal itself as host.', requestId);
        return;
    }
    const signal = getSignalPayload(message.signal);
    if (!signal) {
        sendError(context, 'invalid_signal', 'signal must be a JSON object.', requestId);
        return;
    }
    const host = clients.get(room.hostPlayerId);
    if (!host) {
        sendError(context, 'host_unavailable', 'The room host is not connected.', requestId);
        return;
    }
    player.lastSeenAt = new Date().toISOString();
    room.updatedAt = player.lastSeenAt;
    sendToClient(host, {
        type: 'rtc_signal',
        requestId,
        roomCode: room.code,
        fromPlayerId: player.id,
        signal,
        serverTime: Date.now(),
    });
}
function handleSignalToPeer(context, message, requestId) {
    const room = getContextRoom(context);
    const player = getContextPlayer(context, room);
    if (!room || !player) {
        sendError(context, 'not_in_room', 'Join a room before sending WebRTC signaling.', requestId);
        return;
    }
    if (player.id !== room.hostPlayerId) {
        sendError(context, 'not_room_host', 'Only the room host can signal peers.', requestId);
        return;
    }
    const targetPlayerId = getOptionalString(message.targetPlayerId);
    const signal = getSignalPayload(message.signal);
    if (!targetPlayerId || !room.players.has(targetPlayerId)) {
        sendError(context, 'invalid_target', 'targetPlayerId must be a player in this room.', requestId);
        return;
    }
    if (!signal) {
        sendError(context, 'invalid_signal', 'signal must be a JSON object.', requestId);
        return;
    }
    const target = clients.get(targetPlayerId);
    if (!target) {
        sendError(context, 'target_unavailable', 'The target player is not connected.', requestId);
        return;
    }
    player.lastSeenAt = new Date().toISOString();
    room.updatedAt = player.lastSeenAt;
    sendToClient(target, {
        type: 'rtc_signal',
        requestId,
        roomCode: room.code,
        fromPlayerId: player.id,
        signal,
        serverTime: Date.now(),
    });
}
function addPlayerToRoom(context, room, options) {
    const now = new Date().toISOString();
    room.players.set(context.id, {
        id: context.id,
        name: options.name,
        faction: options.faction,
        ready: false,
        combat: createDefaultPlayerCombatState(),
        joinedAt: now,
        lastSeenAt: now,
    });
    room.updatedAt = now;
}
function leaveCurrentRoom(context, reason) {
    const roomCode = context.roomCode;
    const playerId = context.playerId;
    context.roomCode = null;
    context.playerId = null;
    if (!roomCode || !playerId) {
        return;
    }
    const room = rooms.get(roomCode);
    if (!room) {
        return;
    }
    const wasHost = room.hostPlayerId === playerId;
    const removed = room.players.delete(playerId);
    if (!removed) {
        return;
    }
    if (room.players.size === 0) {
        rooms.delete(room.code);
        return;
    }
    if (wasHost) {
        room.hostPlayerId = Array.from(room.players.values())[0].id;
    }
    room.updatedAt = new Date().toISOString();
    broadcastToRoom(room, {
        type: 'player_left',
        roomCode,
        playerId,
        reason,
        serverTime: Date.now(),
    });
    broadcastRoomState(room);
}
function sendRoomJoined(context, room, requestId) {
    sendToClient(context, {
        type: 'room_joined',
        requestId,
        playerId: context.id,
        room: serializeRoom(room),
        serverTime: Date.now(),
    });
}
function broadcastRoomState(room) {
    broadcastToRoom(room, {
        type: 'room_state',
        room: serializeRoom(room),
        serverTime: Date.now(),
    });
}
function broadcastToRoom(room, message, excludePlayerId) {
    for (const player of room.players.values()) {
        if (player.id === excludePlayerId) {
            continue;
        }
        const target = clients.get(player.id);
        if (target) {
            sendToClient(target, message);
        }
    }
}
function sendToClient(context, message) {
    if (context.socket.readyState === WebSocket.OPEN) {
        context.socket.send(JSON.stringify(message));
    }
}
function sendError(context, code, message, requestId) {
    sendToClient(context, {
        type: 'error',
        requestId,
        code,
        message,
        serverTime: Date.now(),
    });
}
function sendFactionJoinError(context, room, faction, requestId) {
    if (!isFactionAllowedInMode(room.mode, faction)) {
        sendError(context, 'mode_faction_conflict', 'Coop rooms only allow the earth faction.', requestId);
        return;
    }
    sendError(context, 'faction_full', `Faction "${faction}" already has ${MAX_FACTION_PLAYERS} players.`, requestId);
}
function serializeRoom(room) {
    const players = Array.from(room.players.values()).map((player) => ({
        id: player.id,
        name: player.name,
        faction: player.faction,
        ready: player.ready,
        combat: serializePlayerCombat(player.combat),
        isHost: player.id === room.hostPlayerId,
        joinedAt: player.joinedAt,
        lastSeenAt: player.lastSeenAt,
    }));
    return {
        code: room.code,
        name: room.name,
        mode: room.mode,
        hostPlayerId: room.hostPlayerId,
        createdAt: room.createdAt,
        updatedAt: room.updatedAt,
        maxFactionPlayers: MAX_FACTION_PLAYERS,
        score: serializeRoomCombat(room.combat),
        counts: {
            earth: countFaction(room, 'earth'),
            invader: countFaction(room, 'invader'),
        },
        capacity: {
            earth: MAX_FACTION_PLAYERS,
            invader: room.mode === 'coop' ? 0 : MAX_FACTION_PLAYERS,
        },
        players,
    };
}
function serializePlayerCombat(combat) {
    return {
        score: combat.score,
        kills: combat.kills,
        relayIntegrity: combat.relayIntegrity,
        timeRemaining: combat.timeRemaining,
        result: combat.result,
        updatedAt: combat.updatedAt,
    };
}
function serializeRoomCombat(combat) {
    return {
        phase: combat.phase,
        earthScore: combat.earthScore,
        invaderScore: combat.invaderScore,
        earthKills: combat.earthKills,
        invaderKills: combat.invaderKills,
        relayIntegrity: combat.relayIntegrity,
        timeRemaining: combat.timeRemaining,
        winner: combat.winner,
        reason: combat.reason,
        updatedAt: combat.updatedAt,
        completedAt: combat.completedAt,
    };
}
function createDefaultPlayerCombatState() {
    return {
        score: 0,
        kills: 0,
        relayIntegrity: 100,
        timeRemaining: 180,
        result: null,
        updatedAt: null,
    };
}
function createDefaultRoomCombatState() {
    const now = new Date().toISOString();
    return {
        phase: 'active',
        earthScore: 0,
        invaderScore: 0,
        earthKills: 0,
        invaderKills: 0,
        relayIntegrity: 100,
        timeRemaining: 180,
        winner: null,
        reason: null,
        updatedAt: now,
        completedAt: null,
    };
}
function resetRoomCombat(room) {
    room.combat = createDefaultRoomCombatState();
    room.players.forEach((player) => {
        player.combat = createDefaultPlayerCombatState();
    });
    resetRoomReadyState(room);
    room.updatedAt = room.combat.updatedAt;
}
function resetFinishedRoomCombat(room) {
    if (room.combat.phase !== 'finished') {
        return false;
    }
    resetRoomCombat(room);
    return true;
}
function resetRoomReadyState(room) {
    room.players.forEach((player) => {
        player.ready = false;
    });
}
function canJoinFaction(room, faction) {
    return isFactionAllowedInMode(room.mode, faction) && countFaction(room, faction) < MAX_FACTION_PLAYERS;
}
function isFactionAllowedInMode(mode, faction) {
    return mode === 'versus' || faction === 'earth';
}
function countFaction(room, faction) {
    let count = 0;
    for (const player of room.players.values()) {
        if (player.faction === faction) {
            count += 1;
        }
    }
    return count;
}
function getContextRoom(context) {
    return context.roomCode ? rooms.get(context.roomCode) ?? null : null;
}
function getContextPlayer(context, room) {
    if (!room || !context.playerId) {
        return null;
    }
    return room.players.get(context.playerId) ?? null;
}
function createUniqueRoomCode() {
    let code = createRoomCode();
    while (rooms.has(code)) {
        code = createRoomCode();
    }
    return code;
}
function createRoomCode() {
    let code = '';
    for (let index = 0; index < ROOM_CODE_LENGTH; index += 1) {
        code += ROOM_CODE_ALPHABET[randomInt(ROOM_CODE_ALPHABET.length)];
    }
    return code;
}
function normalizeRoomMode(value) {
    return value === 'coop' || value === 'versus' ? value : null;
}
function normalizeFaction(value) {
    return value === 'earth' || value === 'invader' ? value : null;
}
function normalizeRoomCode(value) {
    if (typeof value !== 'string') {
        return null;
    }
    const code = value.trim().toUpperCase();
    return code.length > 0 ? code : null;
}
function normalizeRoomName(value, fallbackCode) {
    if (typeof value !== 'string') {
        return fallbackCode;
    }
    const name = value.trim().replace(/\s+/g, ' ').slice(0, 48);
    return name.length > 0 ? name : fallbackCode;
}
function normalizePlayerName(value, fallbackId) {
    if (typeof value !== 'string') {
        return `Pilot ${fallbackId.slice(0, 4)}`;
    }
    const name = value.trim().replace(/\s+/g, ' ').slice(0, 32);
    return name.length > 0 ? name : `Pilot ${fallbackId.slice(0, 4)}`;
}
function getOptionalString(value) {
    return typeof value === 'string' ? value : undefined;
}
function getSignalPayload(value) {
    return isRecord(value) ? value : null;
}
function isRecord(value) {
    return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}
function sendJsonResponse(response, statusCode, body) {
    response.writeHead(statusCode, {
        'Content-Type': 'application/json; charset=utf-8',
    });
    response.end(`${JSON.stringify(body)}\n`);
}
function setCorsHeaders(response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    response.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    response.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    response.setHeader('Access-Control-Allow-Private-Network', 'true');
}
function rejectUpgrade(socket, statusCode, message) {
    socket.write(`HTTP/1.1 ${statusCode} ${message}\r\n\r\n`);
    socket.destroy();
}
function parseConfig(argv, env) {
    const host = getArgValue(argv, '--host') ?? env.LAN_SERVER_HOST ?? DEFAULT_HOST;
    const rawPort = getArgValue(argv, '--port') ?? env.LAN_SERVER_PORT ?? String(DEFAULT_PORT);
    const port = Number.parseInt(rawPort, 10);
    if (!Number.isInteger(port) || port <= 0 || port > 65_535) {
        throw new Error(`Invalid LAN server port: ${rawPort}`);
    }
    return {
        host,
        port,
    };
}
function getArgValue(argv, name) {
    for (let index = 0; index < argv.length; index += 1) {
        const value = argv[index];
        if (value === name) {
            return argv[index + 1];
        }
        if (value.startsWith(`${name}=`)) {
            return value.slice(name.length + 1);
        }
    }
    return undefined;
}
function shutdown() {
    clearInterval(heartbeatTimer);
    for (const context of clients.values()) {
        context.socket.close(1001, 'server shutdown');
    }
    wsServer.close();
    httpServer.close(() => {
        process.exit(0);
    });
}
//# sourceMappingURL=index.js.map