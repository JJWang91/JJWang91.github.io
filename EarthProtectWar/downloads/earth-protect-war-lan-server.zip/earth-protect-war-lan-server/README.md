# Earth Protect War LAN Signaling Server

This package contains the optional self-hosted WebRTC signaling server for Earth Protect War.

The game uses Artico public signaling by default. Run this service when you want a local LAN signaling endpoint and room discovery. Game snapshots and combat events still travel through browser-to-browser WebRTC DataChannel connections; this service only coordinates rooms and SDP/ICE signaling.

## Requirements

- Node.js 22 or newer

## Start

```bash
npm install
npm start
```

The default address is:

```text
0.0.0.0:8787
```

Other players can connect with:

```text
ws://<server-lan-ip>:8787/ws
```

You can override host and port:

```bash
LAN_SERVER_HOST=0.0.0.0 LAN_SERVER_PORT=8787 npm start
npm start -- --host 0.0.0.0 --port 8787
```
