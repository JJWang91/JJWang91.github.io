# Earth Protect War LAN Server

This package contains the local network room server for Earth Protect War.

## Requirements

- Node.js 22 or newer

## Start

```bash
npm install
npm start
```

The default address is:

```text
0.0.0.0:8787
```

Other players can connect with:

```text
ws://<server-lan-ip>:8787/ws
```

You can override host and port:

```bash
LAN_SERVER_HOST=0.0.0.0 LAN_SERVER_PORT=8787 npm start
npm start -- --host 0.0.0.0 --port 8787
```
